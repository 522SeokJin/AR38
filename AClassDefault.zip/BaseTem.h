#pragma once

// ���� : 
class $safeitemname$
{
private:	// member Var


public:
	// constrcuter destructer
	$safeitemname$(); // default constructer ����Ʈ ������
	~$safeitemname$(); // default destructer ����Ʈ �Ҹ���

public:
	// delete Function
	$safeitemname$(const $safeitemname$& _other) = delete; 
	$safeitemname$($safeitemname$&& _other) noexcept = delete;
	$safeitemname$& operator=(const $safeitemname$& _other) = delete;
	$safeitemname$& operator=(const $safeitemname$&& _other) = delete;

public:
};

